#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_PORT 8080

int main() {
    int clientSocket;
    sockaddr_in serverAddress{};
    const char* clientMessage = "Hola servidor!";
    char responseBuffer[1024];

    // Crear socket del client
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("Error en crear el socket!");
        return 1;
    }

    // Configurar l'adreça del servidor
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, "127.0.0.1", &serverAddress.sin_addr);

    // Connectar al servidor
    if (connect(clientSocket, (sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
        perror("Error en connectar al servidor!");
        return 1;
    }

    // Enviar un missatge al servidor
    send(clientSocket, clientMessage, strlen(clientMessage), 0);
    std::cout << "Missatge enviat: " << clientMessage << "\n";

    // Rebre la resposta del servidor
    read(clientSocket, responseBuffer, sizeof(responseBuffer));
    std::cout << "Resposta del servidor: " << responseBuffer << "\n";

    // Tancar la connexió
    close(clientSocket);
    return 0;
}
