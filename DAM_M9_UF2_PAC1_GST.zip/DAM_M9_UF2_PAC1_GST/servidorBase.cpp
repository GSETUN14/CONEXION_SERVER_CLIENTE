#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define SERVER_PORT 8080

int main() {
    int serverSocket, clientSocket;
    sockaddr_in serverAddress{};
    char receiveBuffer[1024];

    // Crear socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Error en crear el socket!");
        return 1;
    }

    // Configurar adreça del servidor
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(SERVER_PORT);

    // Associa el socket amb el port
    if (bind(serverSocket, (sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
        perror("Error en bind!");
        return 1;
    }

    // Escoltar connexions entrants
    listen(serverSocket, 1);
    std::cout << "Servidor en marxa, escoltant al port " << SERVER_PORT << "...\n";

    // Acceptar connexió del client
    clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket < 0) {
        perror("Error en acceptar connexió!");
        return 1;
    }

    // Llegir el missatge del client
    read(clientSocket, receiveBuffer, sizeof(receiveBuffer));
    std::cout << "Missatge rebut: " << receiveBuffer << "\n";

    // Enviar una resposta al client
    const char* serverMessage = "Hola des del servidor!";
    send(clientSocket, serverMessage, strlen(serverMessage), 0);

    // Tancar connexions
    close(clientSocket);
    close(serverSocket);
    return 0;
}
